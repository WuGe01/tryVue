const hi = 'hi'
const bye = 'bye'

export default {
  hi,
  bye
}