import express from 'express'
import home from './routes/home.js'
import about from './routes/about.js'

const server = express()

server.use('/', home)
server.use('/about', about)

server.listen(3000, () => {
  console.log('http://localhost:3000')
})

