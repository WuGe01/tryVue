import express from 'express'

const route = express.Router()

route.get('/', (req, res) => {
  res.send('about')
})

route.get('/company', (req, res) => {
  res.send('about/company')
})

route.get('/store', (req, res) => {
  res.send('about/store')
})

export default route
