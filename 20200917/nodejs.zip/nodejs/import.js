import exp from './export.js'

console.log(exp)
console.log(exp.hi)
console.log(exp.bye)